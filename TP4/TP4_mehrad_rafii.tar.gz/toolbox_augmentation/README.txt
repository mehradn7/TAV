Run main.m

'augmentation' folder must contain images used to make the augmentation
'image' folder contains input images
'result' folder contains augmented images

