function y = kronecker(a,b)
%% Fonction de Kronecker
if (a==b)
    y = 1;
else
    y = 0;
end