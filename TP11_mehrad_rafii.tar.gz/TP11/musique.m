[signal,f_echantillonnage] = audioread('Audio/Beethoven.wav');
sound(signal,f_echantillonnage);

save musique;